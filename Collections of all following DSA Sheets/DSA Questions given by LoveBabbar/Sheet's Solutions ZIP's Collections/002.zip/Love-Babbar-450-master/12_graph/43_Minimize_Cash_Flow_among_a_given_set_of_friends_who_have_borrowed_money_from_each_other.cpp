/*
    link [greedy]: https://www.geeksforgeeks.org/minimize-cash-flow-among-given-set-friends-borrowed-money/

    ref: greedy/11/min_cash_flow...
*/