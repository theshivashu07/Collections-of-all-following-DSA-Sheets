/*
    sol: https://www.geeksforgeeks.org/detect-negative-cycle-graph-bellman-ford/

    ref: 21_implement_bellman_ford_algorithm
*/