/*
    link: https://www.geeksforgeeks.org/total-number-spanning-trees-graph/
    [nice way to find total no. of spanning tree]
    [also called Kirchhoff’s Theorem]
*/
