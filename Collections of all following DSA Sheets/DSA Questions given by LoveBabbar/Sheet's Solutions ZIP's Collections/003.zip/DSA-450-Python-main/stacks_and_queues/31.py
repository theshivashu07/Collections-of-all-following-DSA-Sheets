# Distance of nearest cell having 1 in a binary matrix
