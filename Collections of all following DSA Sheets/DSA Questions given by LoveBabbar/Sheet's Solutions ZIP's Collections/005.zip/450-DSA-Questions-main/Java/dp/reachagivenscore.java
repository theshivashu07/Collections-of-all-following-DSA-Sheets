package dp;

public class reachagivenscore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static void solve() {
		
	}

}
