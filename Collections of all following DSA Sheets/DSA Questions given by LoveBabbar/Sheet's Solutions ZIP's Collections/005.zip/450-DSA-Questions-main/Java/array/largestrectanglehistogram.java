package array;

public class largestrectanglehistogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static void area(int[] arr) {

	}

}
